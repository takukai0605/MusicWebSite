INSERT INTO users (name,password) VALUES ('tanaka','aaa');
INSERT INTO form (user_id,name,genre,comment,attime) VALUES ('matuki0401','まっちゃん','バラード','こんにちは', CURRENT_TIMESTAMP);
INSERT INTO form (user_id,name,genre,comment,attime) VALUES ('takemoto0501','たけちゃん','J-POP','こんにちは', CURRENT_TIMESTAMP);
INSERT INTO form (user_id,name,genre,comment,attime) VALUES ('umedada0601','うめちゃん','K-POP','こんにちは', CURRENT_TIMESTAMP);