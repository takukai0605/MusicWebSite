package com.example.demo.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.dao.UserDao1;

@Controller
public class UserController1 {
	private final UserDao1 userdao1;

	@Autowired
	public UserController1(UserDao1 userdao1) {
		this.userdao1 = userdao1;
	}

	@RequestMapping("/")
	public String top(Model model) {
		model.addAttribute("title", "新規登録");
		return "index";
	}

	//新規登録画面表示
	@GetMapping("/index")
	public String indexForm(@ModelAttribute User1 user) {
		return "index";
	}

	@PostMapping("/index")
	public String indexSubmit(User1 user, Model model) {
		System.out.println("Received User: " + user);
		EntForm1 entform = new EntForm1();
		entform.setName(user.getName());
		entform.setPassword(user.getPassword());
		userdao1.insertDb(entform);
		return "login";

	}

	//ログイン画面表示
	@GetMapping("/login")
	public String showloginForm() {
		return "login";
	}

	@PostMapping("/login")
	public String login(Model model, EntForm1 entform) {
		// ユーザ名とパスワードの検証
		List<EntForm1> list = userdao1.searchDb();
		boolean isValid = false;

		for (EntForm1 dbUser : list) {
			if (dbUser.getName().equals(entform.getName()) && dbUser.getPassword().equals(entform.getPassword())) {
				isValid = true;
				break;
			}
		}
		if (isValid) {
			model.addAttribute("message", "ログインしました");
			return "success";
		} else {
			model.addAttribute("error", "ユーザ名またはパスワードが正しくありません");
			return "logIn";
		}
	}

}