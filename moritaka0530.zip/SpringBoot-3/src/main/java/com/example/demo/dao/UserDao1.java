package com.example.demo.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.demo.user.EntForm1;

@Repository
public class UserDao1 {

	private final JdbcTemplate db;

	@Autowired
	public UserDao1(JdbcTemplate db) {
		this.db = db;
	}

	public void insertDb(EntForm1 entform) {
		db.update("INSERT INTO `users` (name,password) VALUES(?,?)", entform.getName(), entform.getPassword());
	}

	public List<EntForm1> searchDb() {
		String sql = "SELECT * FROM `users`";
		//データベースから取り出したデータをresultDB1に入れる
		List<Map<String, Object>> resultDb1 = db.queryForList(sql);

		//画面に表示しやすい形のList(resultDB2)を用意
		List<EntForm1> resultDb2 = new ArrayList<EntForm1>();

		//1件ずつピックアップ
		for (Map<String, Object> result1 : resultDb1) {

			//データ1件分を1つのまとまりとしたEntForm型の「entformdb」を生成
			EntForm1 entformdb = new EntForm1();

			//id、name、passwordのデータをentformdbに移す
			entformdb.setId((int) result1.get("id"));
			entformdb.setName((String) result1.get("name"));
			entformdb.setPassword((String) result1.get("password"));

			//移し替えたデータを持ったentformdbを、resultDB2に入れる
			resultDb2.add(entformdb);
		}

		//Controllerに渡す
		return resultDb2;
	}
}
